import secrets
import string

def generate_password(length):
    if length < 4:
        print("Password length should be at least 4")
        return

    characters = (
        string.ascii_lowercase +
        string.ascii_uppercase +
        string.digits +
        string.punctuation
    )

    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password


# Main Program
try:
    length = int(input("Enter password length: "))
    password = generate_password(length)
    if password:
        print("Generated Strong Password:", password)
except ValueError:
    print("Please enter a valid number.")
